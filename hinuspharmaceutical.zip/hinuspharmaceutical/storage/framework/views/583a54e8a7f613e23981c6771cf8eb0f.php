  <?php if (isset($component)) { $__componentOriginal292c42cda3271405dc664835e31595e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal292c42cda3271405dc664835e31595e3 = $attributes; } ?>
<?php $component = App\View\Components\FrontendLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FrontendLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div class="breadcumb-wrapper " data-bg-src="<?php echo e(asset('frontend/assets/img/bg/breadcumb-bg.jpg')); ?>">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Shop</h1>
                <ul class="breadcumb-menu">
                    <li><a href="home-medical-clinic.html">Home</a></li>
                    <li>Shop</li>
                </ul>
            </div>
        </div>
    </div>
    <!--==============================
Product Area
==============================-->
    <section class="space-top space-extra-bottom">
        <div class="container">
            <div class="row gy-40">
                                <?php $__currentLoopData = $ProductsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-xl-3 col-lg-4 col-sm-6 ">
                    <div class="th-product product-grid">
                        <div class="product-img">
                            <img src="<?php echo e(asset(config('constant.IMG_DIR.MAIN_IMAGE').'/'.$item->main_image)); ?>" alt="Product Image">
                            <div class="actions">
                                <a href="#QuickView" class="icon-btn popup-content"><i class="far fa-eye"></i></a>
                                <a href="cart.html" class="icon-btn"><i class="far fa-cart-plus"></i></a>
                                <a href="wishlist.html" class="icon-btn"><i class="far fa-heart"></i></a>
                            </div>
                        </div>
                        <div class="product-content">
                            <a href="<?php echo e(route('user.shopDetail',['slug'=>$item->slug])); ?>" class="product-category"> <?php echo e($item->category->cat_name); ?></a>
                            <h3 class="product-title"><a href="<?php echo e(route('user.shopDetail',['slug'=>$item->slug])); ?>"> <?php echo e($item->title); ?></a></h3>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
           
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $attributes = $__attributesOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__attributesOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $component = $__componentOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__componentOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\hinuspharmaceutical\resources\views/frontend/shop.blade.php ENDPATH**/ ?>