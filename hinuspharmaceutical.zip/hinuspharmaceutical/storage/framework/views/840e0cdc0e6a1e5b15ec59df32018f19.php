   <?php if (isset($component)) { $__componentOriginal292c42cda3271405dc664835e31595e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal292c42cda3271405dc664835e31595e3 = $attributes; } ?>
<?php $component = App\View\Components\FrontendLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FrontendLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
       <!--==============================
    Breadcumb
============================== -->
       <div class="breadcumb-wrapper " data-bg-src="<?php echo e(asset('frontend/assets/img/bg/breadcumb-bg.jpg')); ?>">
           <div class="container">
               <div class="breadcumb-content">
                   <h1 class="breadcumb-title"><?php echo e($ProductData->title); ?></h1>
                   <ul class="breadcumb-menu">
                       <li><a href="<?php echo e(route('user.index')); ?>">Home</a></li>
                       <li><?php echo e($ProductData->title); ?></li>
                   </ul>
               </div>
           </div>
       </div><!--==============================
    Product Details
    ==============================-->
       <section class="product-details space-top space-extra-bottom">
           <div class="container">
               <div class="row gx-60">
                <center>
                   <div class="col-lg-6">
                       <div class="product-big-img">
                           <div class="img p-5">
                            <img src="<?php echo e(asset(config('constant.IMG_DIR.MAIN_IMAGE').'/'.$ProductData->main_image)); ?>"
                                   alt="Product Image"></div>
                           <div class="row p-4">
                            <?php if(!empty($ProductData->other_images)): ?>
                                
                            <?php $__currentLoopData = json_decode($ProductData->other_images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <div class="col-xl-3 col-lg-4 col-sm-6 ">
                                   <div class="th-product product-grid">
                                       <div class="product-img">
                                           <img src="<?php echo e(asset(config('constant.IMG_DIR.OTHER_IMAGE').'/'.$item)); ?>"
                                               alt="Product Image">
                                       </div>
                                   </div>
                               </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                           </div>
                       </div>
                   </div>
                   </center>
                   <div class="col-lg-12 align-self-center mt-5">
                       <div class="product-about">
                          
                           <h2 class="product-title"><?php echo e($ProductData->title); ?></h2>
                           <div class="mt-2 link-inherit">
                               <p>
                                   <strong class="text-title me-3">Availability:</strong>
                                   <span class="stock in-stock"><i class="far fa-check-square me-2 ms-1"></i>In
                                       Stock</span>
                               </p>
                           </div>

                           <div class="product_meta">
                               <span class="posted_in">Category: <a href="#"><?php echo e($ProductData->category->cat_name); ?></a></span>
                           </div>
                       </div>
                   </div>
               </div>
               <ul class="nav product-tab-style1" id="productTab" role="tablist">
                   <li class="nav-item" role="presentation">
                       <a class="nav-link th-btn active" id="description-tab" data-bs-toggle="tab" href="#description"
                           role="tab" aria-controls="description" aria-selected="true">Product Description</a>
                   </li>
               </ul>
               <div class="tab-content" id="productTabContent">
                   <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
<?php echo $ProductData->description; ?>

                   </div>
               </div>
           </div>
       </section>
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $attributes = $__attributesOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__attributesOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal292c42cda3271405dc664835e31595e3)): ?>
<?php $component = $__componentOriginal292c42cda3271405dc664835e31595e3; ?>
<?php unset($__componentOriginal292c42cda3271405dc664835e31595e3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hinuspharmaceutical\resources\views/frontend/shop-detail.blade.php ENDPATH**/ ?>