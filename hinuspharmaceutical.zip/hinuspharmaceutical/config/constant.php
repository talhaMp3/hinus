<?php

return [

    'IMG_DIR' => [
        'CATEGORY_IMAGE' => 'category_image',
        'NO_IMAGE' => 'assets/images/image.png',
        'MAIN_IMAGE' => 'main_image',
        'OTHER_IMAGE' => 'other_image',
        'HERO_IMAGE' => 'hore_image',
        'MINI_IMAGE' => 'mini_image',
        'LOGO' => 'assets/images/logo.png',
    ],


];
